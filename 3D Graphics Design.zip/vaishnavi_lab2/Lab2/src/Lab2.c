/*
===============================================================================
 Name        : Lab2.c
 Author      : $(SAMHITHA MAMINDLA (011810175) AND SAI SREE VAISHNAVI CHITTOORI (012415130))
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/



#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "LPC17xx.h"                        /* LPC17xx definitions */
#include "ssp.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Be careful with the port number and location number, because

 some of the location may not exist in that port. */

#define PORT_NUM            0

uint8_t src_addr[SSP_BUFSIZE];
uint8_t dest_addr[SSP_BUFSIZE];

#define ST7735_TFTWIDTH 127
#define ST7735_TFTHEIGHT 159

#define ST7735_CASET 0x2A
#define ST7735_RASET 0x2B
#define ST7735_RAMWR 0x2C
#define ST7735_SLPOUT 0x11
#define ST7735_DISPON 0x29

//
#define swap_int16_t(a, b) { int16_t t = a; a = b; b = t; }
struct coordinate_pnt {
	int x;
	int y;
};
struct coordinates{
int x;
int y;
};
int cam_x = 90;
int cam_y = 90;
int cam_z = 90;
int light_x = 50;
int light_y = 50;
int light_z = 50;
int xCam = 100;
int yCam = 100;
int zCam = 100;

#define swap(x, y) {x = x + y; y = x - y; x = x - y ;}

// defining color values

#define LIGHTBLUE 0x00FFE0
#define GREEN 0x00FF00
#define DARKBLUE 0x000033
#define BLACK 0x000000
#define BLUE 0x0007FF
#define RED 0xFF0000
#define MAGENTA 0x00F81F
#define WHITE 0xFFFFFF
#define PURPLE 0xCC33FF
#define random(x) (rand()%x)

int _height = ST7735_TFTHEIGHT;
int _width = ST7735_TFTWIDTH;
double mySin(double a);
double myCos(double a);

void spiwrite(uint8_t c)

{

	int pnum = 0;

	src_addr[0] = c;

	SSP_SSELToggle(pnum, 0);

	SSPSend(pnum, (uint8_t *) src_addr, 1);

	SSP_SSELToggle(pnum, 1);

}

void writecommand(uint8_t c)

{

	LPC_GPIO0->FIOCLR |= (0x1 << 21);

	spiwrite(c);

}

void writedata(uint8_t c)

{

	LPC_GPIO0->FIOSET |= (0x1 << 21);

	spiwrite(c);

}

void writeword(uint16_t c)

{

	uint8_t d;

	d = c >> 8;

	writedata(d);

	d = c & 0xFF;

	writedata(d);

}

void write888(uint32_t color, uint32_t repeat)

{

	uint8_t red, green, blue;

	int i;

	red = (color >> 16);

	green = (color >> 8) & 0xFF;

	blue = color & 0xFF;

	for (i = 0; i < repeat; i++) {

		writedata(red);

		writedata(green);

		writedata(blue);

	}

}

void setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)

{

	writecommand(ST7735_CASET);

	writeword(x0);

	writeword(x1);

	writecommand(ST7735_RASET);

	writeword(y0);

	writeword(y1);

}

void fillrect(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

	int16_t i;

	int16_t width, height;

	width = x1 - x0 + 1;

	height = y1 - y0 + 1;

	setAddrWindow(x0, y0, x1, y1);

	writecommand(ST7735_RAMWR);

	write888(color, width * height);

}

void lcddelay(int ms)

{

	int count = 24000;

	int i;

	for (i = count * ms; i--; i > 0)
		;

}

void lcd_init()

{

	int i;
	printf("LCD Demo Begins!!!\n");
	// Set pins P0.16, P0.21, P0.22 as output
	LPC_GPIO0->FIODIR |= (0x1 << 16);

	LPC_GPIO0->FIODIR |= (0x1 << 21);

	LPC_GPIO0->FIODIR |= (0x1 << 22);

	// Hardware Reset Sequence
	LPC_GPIO0->FIOSET |= (0x1 << 22);
	lcddelay(500);

	LPC_GPIO0->FIOCLR |= (0x1 << 22);
	lcddelay(500);

	LPC_GPIO0->FIOSET |= (0x1 << 22);
	lcddelay(500);

	// initialize buffers
	for (i = 0; i < SSP_BUFSIZE; i++) {

		src_addr[i] = 0;
		dest_addr[i] = 0;
	}

	// Take LCD display out of sleep mode
	writecommand(ST7735_SLPOUT);
	lcddelay(200);

	// Turn LCD display on
	writecommand(ST7735_DISPON);
	lcddelay(200);

}

void drawPixel(int16_t x, int16_t y, uint32_t color)

{

	if ((x < 0) || (x >= _width) || (y < 0) || (y >= _height))

		return;

	setAddrWindow(x, y, x + 1, y + 1);

	writecommand(ST7735_RAMWR);

	write888(color, 1);

}

/*****************************************************************************


 ** Descriptions:        Draw line function

 **

 ** parameters:           Starting point (x0,y0), Ending point(x1,y1) and color

 ** Returned value:        None

 **

 *****************************************************************************/

void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

	int16_t slope = abs(y1 - y0) > abs(x1 - x0);

	if (slope) {

		swap(x0, y0);

		swap(x1, y1);

	}

	if (x0 > x1) {

		swap(x0, x1);

		swap(y0, y1);

	}

	int16_t dx, dy;

	dx = x1 - x0;

	dy = abs(y1 - y0);

	int16_t err = dx / 2;

	int16_t ystep;

	if (y0 < y1) {

		ystep = 1;

	}

	else {

		ystep = -1;

	}

	for (; x0 <= x1; x0++) {

		if (slope) {

			drawPixel(y0, x0, color);

		}

		else {

			drawPixel(x0, y0, color);

		}

		err -= dy;

		if (err < 0) {

			y0 += ystep;

			err += dx;

		}

	}

}


int calIDiff(int16_t xPs, int16_t yPs, int16_t zPs, int16_t xPi, int16_t yPi,
		int16_t zPi, int16_t k) {
	double cosVal;
	double r = sqrt(
			pow((zPs - zPi), 2) + pow((yPs - yPi), 2) + pow((xPs - xPi), 2));
	double rcos = sqrt(pow((zPs - zPi), 2));
	cosVal = rcos / r;
	return (255 * k * cosVal) / pow(r, 2);
}

struct coordinate_pnt project_coordinates(int x_w, int y_w, int z_w) {
	int scrn_x, scrn_y, Dist = 100, x_diff = 74, y_diff = 100;
	double x_p, y_p, z_p, theta, phi, rho;
	struct coordinate_pnt screen;
	theta = acos(cam_x / sqrt(pow(cam_x, 2) + pow(cam_y, 2)));
	phi = acos(cam_z / sqrt(pow(cam_x, 2) + pow(cam_y, 2) + pow(cam_z, 2)));
	//theta = 0.785;
	//phi = 0.785;
	rho = sqrt((pow(cam_x, 2)) + (pow(cam_y, 2)) + (pow(cam_z, 2)));
	x_p = (y_w * cos(theta)) - (x_w * sin(theta));
	y_p = (z_w * sin(phi)) - (x_w * cos(theta) * cos(phi))
			- (y_w * cos(phi) * sin(theta));
	z_p = rho - (y_w * sin(phi) * cos(theta)) - (x_w * sin(phi) * cos(theta))
			- (z_w * cos(phi));
	scrn_x = x_p * Dist / z_p;
	scrn_y = y_p * Dist / z_p;
	scrn_x = x_diff + scrn_x;
	scrn_y = y_diff - scrn_y;
	screen.x = scrn_x;
	screen.y = scrn_y;
	return screen;
}

struct coordinate_pnt newProject_coordinates(int x_w, int y_w, int z_w) {
	int scrn_x, scrn_y, Dist = 100, x_diff = 74, y_diff = 30;
//	int scrn_x, scrn_y, Dist = 100, x_diff = 74, y_diff = 70;
	double x_p, y_p, z_p, theta, phi, rho;
	struct coordinate_pnt screen;
	theta = acos(cam_x / sqrt(pow(cam_x, 2) + pow(cam_y, 2)));
	phi = acos(cam_z / sqrt(pow(cam_x, 2) + pow(cam_y, 2) + pow(cam_z, 2)));
	//theta = 0.785;
	//phi = 0.785;
	rho = sqrt((pow(cam_x, 2)) + (pow(cam_y, 2)) + (pow(cam_z, 2)));
	x_p = (y_w * cos(theta)) - (x_w * sin(theta));
	y_p = (z_w * sin(phi)) - (x_w * cos(theta) * cos(phi))
			- (y_w * cos(phi) * sin(theta));
	z_p = rho - (y_w * sin(phi) * cos(theta)) - (x_w * sin(phi) * cos(theta))
			- (z_w * cos(phi));
	scrn_x = x_p * Dist / z_p;
	scrn_y = y_p * Dist / z_p;
	scrn_x = x_diff + scrn_x;
	scrn_y = y_diff - scrn_y;
	screen.x = scrn_x;
	screen.y = scrn_y;
	return screen;
}

void diffused_reflection() {
	struct coordinate_pnt lcd;
	struct coordinate_pnt tmp;
	int x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7, x8, y8;
	lcd = project_coordinates(0, 0, 0);
	x1 = lcd.x;
	y1 = lcd.y;
	lcd = project_coordinates(45, 0, 0);
	x2 = lcd.x;
	y2 = lcd.y;
	lcd = project_coordinates(0, 45, 0);
	x3 = lcd.x;
	y3 = lcd.y;
	lcd = project_coordinates(0, 0, 45);
	x4 = lcd.x;
	y4 = lcd.y;
	lcd = project_coordinates(45, 0, 45);
	x5 = lcd.x;
	y5 = lcd.y;
	lcd = project_coordinates(45, 45, 0);
	x6 = lcd.x;
	y6 = lcd.y;
	lcd = project_coordinates(45, 45, 45);
	x7 = lcd.x;
	y7 = lcd.y;
	lcd = project_coordinates(0, 45, 45);
	x8 = lcd.x;
	y8 = lcd.y;
	for (int i = 0; i <= 45; i++) {
		for (int j = 0; j <= 45; j++) {
			tmp = project_coordinates(i, j, 45);
			int kR = calIDiff(light_x, light_y, light_z, i, j, 45, 255);
			if (kR + 150 > 255) {
				kR = 255;
			} else {
				kR += 150;
			}
			uint32_t color = 0x000000;
			color |= ((kR |= 0x000000) << 16);
			color |= (0x000000 << 8);
			color |= 0x000000;
			drawPixel(tmp.x, tmp.y, color);
		}
	}
    for (int i = 0; i <= 45; i++) {
    	for (int j = 0; j <= 45; j++) {
    		tmp = project_coordinates (45,i,j);
    		int kR = calIDiff(light_x, light_y, light_z, 45, i, j, 255);
    		if (kR + 150 > 255) {
    		    kR = 255;
    		    } else {
    		    	kR += 150;
    		    }
    		uint32_t color = 0x000000;
    		color |= (0x000000 << 16);
    		color |= ((kR |= 0x000000) << 8);
    		color |= 0x000000;
    		drawPixel(tmp.x,tmp.y,color);
    	}
    }
    for (int i = 0; i <= 45; i++) {
        	for (int j = 0; j <= 45; j++) {
        		tmp = project_coordinates (i,45,j);
        		int kR = calIDiff(light_x, light_y, light_z, 45, i, j, 255);
        		if (kR + 150 > 255) {
        		    kR = 255;
        		    } else {
        		    	kR += 150;
        		    }
        		uint32_t color = 0x000000;
        		color |= (0x000000 << 16);
        		color |= (0x000000 << 8);
        		color |= (kR |= 0x000000);
        		drawPixel(tmp.x,tmp.y,color);
        	}
        }
	struct coordinate_pnt tmp1;
//    struct coordinate_pnt tmp2;
	for (int i = 10; i <= 15; i++) {
		for (int j = 10; j <= 35; j++) {
			tmp1 = project_coordinates(i, j, 45);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 15; i <= 35; i++) {
		for (int j = 20; j <= 25; j++) {
			tmp1 = project_coordinates(i, j, 45);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 10; i <= 15; i++) {
		for (int j = 10; j <= 35; j++) {
			tmp1 = project_coordinates(i, 45, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 15; i <= 35; i++) {
		for (int j = 20; j <= 25; j++) {
			tmp1 = project_coordinates(i, 45, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 10; i <= 15; i++) {
		for (int j = 10; j <= 35; j++) {
			tmp1 = project_coordinates(45, i, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 15; i <= 35; i++) {
		for (int j = 20; j <= 25; j++) {
			tmp1 = project_coordinates(45, i, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}

}
void cube_generation() {
	struct coordinate_pnt lcd;
	struct coordinate_pnt tmp;
	int x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7, x8, y8;
	lcd = newProject_coordinates(0, 0, 0);
	x1 = lcd.x;
	y1 = lcd.y;
	lcd = newProject_coordinates(45, 0, 0);
	x2 = lcd.x;
	y2 = lcd.y;
	lcd = newProject_coordinates(0, 45, 0);
	x3 = lcd.x;
	y3 = lcd.y;
	lcd = newProject_coordinates(0, 0, 45);
	x4 = lcd.x;
	y4 = lcd.y;
	lcd = newProject_coordinates(45, 0, 45);
	x5 = lcd.x;
	y5 = lcd.y;
	lcd = newProject_coordinates(45, 45, 0);
	x6 = lcd.x;
	y6 = lcd.y;
	lcd = newProject_coordinates(45, 45, 45);
	x7 = lcd.x;
	y7 = lcd.y;
	lcd = newProject_coordinates(0, 45, 45);
	x8 = lcd.x;
	y8 = lcd.y;
	for (int i = 0; i <= 45; i++) {
		for (int j = 0; j <= 45; j++) {
			tmp = newProject_coordinates(i, j, 45);
			drawPixel(tmp.x, tmp.y, 0xFF0000);
		}
	}
    for (int i = 0; i <= 45; i++) {
    	for (int j = 0; j <= 45; j++) {
    		tmp = newProject_coordinates (45,i,j);
    		drawPixel(tmp.x,tmp.y,0x00FF00);
    	}
    }
    for (int i = 0; i <= 45; i++) {
        	for (int j = 0; j <= 45; j++) {
        		tmp = newProject_coordinates (i,45,j);
        		drawPixel(tmp.x,tmp.y,0x0000FF);
        	}
        }
	struct coordinate_pnt tmp1;
	for (int i = 10; i <= 15; i++) {
		for (int j = 10; j <= 35; j++) {
			tmp1 = newProject_coordinates(i, j, 45);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 15; i <= 35; i++) {
		for (int j = 20; j <= 25; j++) {
			tmp1 = newProject_coordinates(i, j, 45);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 10; i <= 15; i++) {
		for (int j = 10; j <= 35; j++) {
			tmp1 = newProject_coordinates(i, 45, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 15; i <= 35; i++) {
		for (int j = 20; j <= 25; j++) {
			tmp1 = newProject_coordinates(i, 45, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 10; i <= 15; i++) {
		for (int j = 10; j <= 35; j++) {
			tmp1 = newProject_coordinates(45, i, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
	for (int i = 15; i <= 35; i++) {
		for (int j = 20; j <= 25; j++) {
			tmp1 = newProject_coordinates(45, i, j);
			drawPixel(tmp1.x, tmp1.y, BLACK);
		}
	}
}


//

struct coordinates project2D(int xWorld, int yWorld, int zWorld)
{
int xScreen, yScreen, eyeScrnDist=100, dx=86, dy=50;
double xPrime, yPrime, zPrime, theta, phi, rho;
struct coordinates screen;
//theta = theta*pi/180;
//phi = phi*pi/180;
theta = acos(xCam/sqrt(pow(xCam,2)+pow(yCam,2)));
phi = acos(zCam/sqrt(pow(xCam,2)+pow(yCam,2)+pow(zCam,2)));
//theta = 0.785;
//phi = 0.785;
rho= sqrt((pow(xCam,2))+(pow(yCam,2))+(pow(zCam,2)));
xPrime = (yWorld*cos(theta))-(xWorld*sin(theta));
yPrime = (zWorld*sin(phi))-(xWorld*cos(theta)*cos(phi))-
(yWorld*cos(phi)*sin(theta));
zPrime = rho-(yWorld*sin(phi)*cos(theta))-
(xWorld*sin(phi)*cos(theta))-(zWorld*cos(phi));
xScreen = xPrime*eyeScrnDist/zPrime;
yScreen = yPrime*eyeScrnDist/zPrime;
xScreen = dx+xScreen;
yScreen = dy-yScreen;
screen.x = xScreen;
screen.y = yScreen;
return screen;
}

void draw_Shadow(double inti_pos, double size, double shadow_Xposition, double shadow_Yposition, double shadow_Zposition)
{
int x_pos[8]={0}, y_pos[8]={0}, z_pos[8]={0};
struct coordinates coord1,coord2,coord3,coord4;
double x[8] = {inti_pos,(inti_pos+size), (inti_pos+size),inti_pos,inti_pos,(inti_pos+size), (inti_pos+size),inti_pos};
double y[8] = {inti_pos, inti_pos, inti_pos+size, inti_pos+size, inti_pos, inti_pos, (inti_pos+size), (inti_pos+size) };
double z[8] = {inti_pos, inti_pos, inti_pos, inti_pos, (inti_pos+size), (inti_pos+size), (inti_pos+size), (inti_pos+size)};
int i;
for(i=0; i<8; i++){
x_pos[i]=x[i]-((z[i]/(shadow_Zposition-z[i]))*(shadow_Xposition-x[i]));
y_pos[i]=y[i]-((z[i]/(shadow_Zposition-z[i]))*(shadow_Yposition-y[i]));
z_pos[i]=z[i]-((z[i]/(shadow_Zposition-z[i]))*(shadow_Zposition-z[i]));
}
coord1 = project2D(x_pos[4],y_pos[4],z_pos[4]);
coord2 = project2D(x_pos[5],y_pos[5],z_pos[5]);
coord3 = project2D(x_pos[6],y_pos[6],z_pos[6]);
coord4 = project2D(x_pos[7],y_pos[7],z_pos[7]);
drawLine(coord1.x, coord1.y, coord2.x, coord2.y,BLACK);
drawLine(coord2.x, coord2.y, coord3.x, coord3.y,BLACK);
drawLine(coord3.x, coord3.y, coord4.x, coord4.y,BLACK);
drawLine(coord1.x, coord1.y, coord4.x, coord4.y,BLACK);
fill_Triangle(coord1.x,coord1.y,coord2.x,coord2.y,coord3.x,coord3.y,BLACK);
fill_Triangle(coord1.x,coord1.y,coord3.x,coord3.y,coord4.x,coord4.y,BLACK);
}


void fill_Triangle(int16_t x0, int16_t y0,int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint32_t color) {
int16_t x, y, j, l;
if (y0 > y1) {
swap_int16_t(y0, y1);
swap_int16_t(x0, x1);
}
if (y1 > y2) {
swap_int16_t(y2, y1);
swap_int16_t(x2, x1);
}
if (y0 > y1) {
swap_int16_t(y0, y1);
swap_int16_t(x0, x1);
}
if(y0 == y2) {
x = y = x0;
if(x1 < x) x = x1;
else if(x1 > y) y = x1;
if(x2 < x) x = x2;
else if(x2 > y) y = x2;
draw_HorizontalLine(x, y0, y-x+1, color);
return;
}
int16_t dx01 = x1 - x0, dy01 = y1 - y0, dx02 = x2 - x0, dy02 = y2 - y0, dx12 = x2 - x1, dy12 = y2 - y1;
int32_t sa = 0, sb = 0;
if(y1 == y2) l = y1;
else l = y1-1;
for(j=y0; j<=l; j++) {
x = x0 + sa / dy01;
y = x0 + sb / dy02;
sa += dx01;
sb += dx02;
if(x > y) swap_int16_t(x,y);
draw_HorizontalLine(x, j, y-x+1, color);
}
sa = dx12 * (j - y1);
sb = dx02 * (j - y0);
for(; j<=y2; j++) {
x = x1 + sa / dy12;
y = x0 + sb / dy02;
sa += dx12;
sb += dx02;
if(x > y) swap_int16_t(x,y);
draw_HorizontalLine(x, j, y-x+1, color);
}
}





void draw_HorizontalLine(int16_t x, int16_t y, int16_t width, uint32_t color)
{
drawLine(x, y, x+width-1, y, color);
}


void axis_generation()
{
struct coordinates lcd;
int x1,y1,x2,y2, x3,y3,x4,y4;	//draw world coordinate system
lcd = project2D(0,0,0);
x1=lcd.x;
y1=lcd.y;
lcd = project2D(100,0,0);
x2=lcd.x;
y2=lcd.y;
lcd = project2D(0,100,0);
x3=lcd.x;
y3=lcd.y;
lcd = project2D(0,0,100);
x4=lcd.x;
y4=lcd.y;
drawLine(x1-30,y1-10,x2,y2,0x00FF0000); //x axis red
drawLine(x1-30,y1-10,x3,y3,0x0000FF00); //y axis green
drawLine(x1-30, y1-10, x4, y4,0x000000FF); //z axis blue
}


int main(void)

{

	uint32_t pnum = PORT_NUM;

	pnum = 0;

	if (pnum == 0)
		SSP0Init();

	else
		puts("Port number is not correct");

	lcd_init();

	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT, WHITE);
	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT, 0X00FFA500);
	axis_generation();
	cube_generation();
	diffused_reflection();
	int size = 45, startPt = 5;
	draw_Shadow(startPt,size, -280,300,350);
	return 0;

}

